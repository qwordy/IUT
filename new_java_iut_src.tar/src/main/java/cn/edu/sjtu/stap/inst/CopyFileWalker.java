package cn.edu.sjtu.stap.inst;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Stack;

import org.apache.commons.io.DirectoryWalker;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

import cn.edu.sjtu.stap.Logger;

public class CopyFileWalker extends DirectoryWalker {

	Set<String> srcDirs;
	File rootDir;
	String currentBasePath = "";
	String outputDirPath;
	Stack<String> dirStack;
	
	public CopyFileWalker(String rootDir, Collection<String> srcDirs) {
		this(rootDir, srcDirs, null);
	}

	public CopyFileWalker(String rootDir, Collection<String> srcDirs, String outputPath) {
		super();
		this.rootDir = new File(rootDir);
		this.srcDirs = new HashSet<String>();
		this.dirStack = new Stack<String>();
		
		if (rootDir.endsWith("/")) {
			rootDir = rootDir.substring(0, rootDir.length() - 1);
		}
		
		if (outputPath == null) {
			this.outputDirPath = rootDir + ".inst";
		} else {
			this.outputDirPath = outputPath;
		}
		
		
		try {
			File outputDir = new File(this.outputDirPath);
			
			if (outputDir.exists()) {
				Logger.error(outputDir + " is existed!");
				return;
			}
			
			for (String srcDir : srcDirs) {
				File fileName = new File(rootDir, srcDir);
				if (fileName.exists() && fileName.isDirectory()) {
					this.srcDirs.add(fileName.getCanonicalPath());
				} else {
					Logger.warn("Source folder: " + srcDir + " not found!");
				}
			}
			
			try {
				List<Object> result = new ArrayList<Object>();
				Logger.debug(this.rootDir.getCanonicalPath());
				walk(this.rootDir, result);
			} catch (IOException e) {
				Logger.error(e.getMessage());
			}
		} catch (Exception e) {
			// e.printStackTrace();
			Logger.error(e.getMessage());
		}

	}
	
	private String _getCurrentBasePath () {
		String currentBasePath = ".";
		for (int i = 1; i < this.dirStack.size(); i ++) {
			currentBasePath = FilenameUtils.concat(currentBasePath, dirStack.get(i));
		}
		return currentBasePath;
	}

	@Override
	protected void handleDirectoryStart(File directory, int depth,
			Collection results) {
		this.dirStack.push(directory.getName());
		this.currentBasePath = this._getCurrentBasePath();

	}
	
	@Override
	protected void handleDirectoryEnd(File directory, int depth, Collection results) {
		this.dirStack.pop();
		this.currentBasePath = this._getCurrentBasePath();

	}

	@Override
	protected boolean handleDirectory(File directory, int depth,
			Collection results) {
		try {
			// this.currentBasePath = this._getCurrentBasePath();
			String dirName = directory.getCanonicalPath();
			File outputFolder = null;
			if (depth == 0) {
				outputFolder = new File(this.outputDirPath, this.currentBasePath);
			} else {
				outputFolder = new File(FilenameUtils.concat(this.outputDirPath, this.currentBasePath),
						directory.getName());
			}


			if (srcDirs.contains(dirName)) {
				Logger.info("source dir found: " + dirName);
				new InstFileWalker(directory, outputFolder.getCanonicalPath());
				return false;
			} else {
				FileUtils.forceMkdir(outputFolder);
				Logger.debug("Making dir " + outputFolder.getCanonicalPath());
				return true;
			}
		} catch (Exception e) {		
			e.printStackTrace();
			Logger.error(e.getMessage());
			System.exit(-1);
		}

		return false;

	}

	@Override
	protected void handleFile(File file, int depth, Collection results) {
		try {
			
			File outputFile = new File(FilenameUtils.concat(this.outputDirPath, this.currentBasePath), 
					file.getName());
			Logger.debug("Copying to: " + depth + ", "+ outputFile.getCanonicalPath());
			FileUtils.copyFile(file, outputFile, true);
		} catch (Exception e) {
			e.printStackTrace();
			Logger.error(e.getMessage());
			System.exit(-1);
		}

		// System.exit(-1);
		
	}

}
