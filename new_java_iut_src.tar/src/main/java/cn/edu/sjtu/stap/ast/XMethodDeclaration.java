package cn.edu.sjtu.stap.ast;

import java.util.List;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.MethodDeclaration;

import cn.edu.sjtu.stap.Util;

/**
 * The wrapper class for the method declaration
 * @author yejiabin
 *
 */
public class XMethodDeclaration {

	MethodDeclaration methodDecl;
	String id;
	
	public XMethodDeclaration (MethodDeclaration methodDecl, String id) {
		this.methodDecl = methodDecl;
		Block block = this.methodDecl.getBody();
		// block.accept(new CanonicalVisitor());
		this.id = id;
	}
	
	public String getId () {
		return id;
	}
	
	public String toString() {

		return id;
	}
	
	private String _getId () {
		// this.methodDecl.get
		return Util.getMethodSignature(methodDecl);
	}
	
	public ASTNode getCanonical() {
		return this.methodDecl;
	}
	
	public MethodDeclaration getOrigin() {
		return this.methodDecl;
	}
	
	
}
