package cn.edu.sjtu.stap.db.entity;

public class TestCase {
	int id;
	
}
