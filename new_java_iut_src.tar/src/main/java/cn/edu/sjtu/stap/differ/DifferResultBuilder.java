package cn.edu.sjtu.stap.differ;

public class DifferResultBuilder {

	public DifferResultBuilder () {
		
	}
	
	public DifferResultBuilder add(DifferUnit du) {
		
		return this;
	}
}
