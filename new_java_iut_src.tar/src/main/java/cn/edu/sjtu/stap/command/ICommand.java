package cn.edu.sjtu.stap.command;

public interface ICommand {
	void process();
}
