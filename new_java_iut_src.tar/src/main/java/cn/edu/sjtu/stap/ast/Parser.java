package cn.edu.sjtu.stap.ast;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.ITypeRoot;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.AbstractTypeDeclaration;
import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.MethodDeclaration;

public class Parser {
	List<XMethodDeclaration> xMethodDecls;
	
	public Parser(String source) {
		ASTParser parser = ASTParser.newParser(AST.JLS3);
		
		parser.setKind(ASTParser.K_COMPILATION_UNIT);
		parser.setSource(source.toCharArray());
		Map options = JavaCore.getOptions();
		options.put(JavaCore.COMPILER_COMPLIANCE, JavaCore.VERSION_1_6);
		options.put(JavaCore.COMPILER_CODEGEN_TARGET_PLATFORM,
				JavaCore.VERSION_1_6);
		options.put(JavaCore.COMPILER_SOURCE, JavaCore.VERSION_1_6);
		parser.setCompilerOptions(options);
		// parser.
		CompilationUnit result = (CompilationUnit)parser.createAST(null);
		String packageName = "";
		if (result.getPackage() != null) {
			packageName = result.getPackage().getName().toString();
		}
		CanonicalVisitor visitor = new CanonicalVisitor(packageName);
		result.accept(visitor);
		
		
		xMethodDecls = visitor.getMethodIds();
		
		// List<AbstractTypeDeclaration> typeList = result.types();
		
		
	}
	
	public List<XMethodDeclaration> getCanonicalMethodDecls () {
		return this.xMethodDecls;
	}
}
