package cn.edu.sjtu.stap;

// import org.pmw.tinylog.Logger;

import java.io.File;
import java.util.List;



public class Config {
	public static String instPrefix = "-*-*-";
	public static String instSeperator = ":";
	public static String logLevel = "";
	public static String rootDir = "";
	public static String projectType = "gradle";
	public static List<String> srcdirs = null;
	public static String project = "";
	
	public static class DB {
		public static String type = "sqlite";
		public static String host = "";
		public static String db = "";
		public static String username = "";
		public static String password = "";
	}
	
	// public static final Logger logger = LogManager.getLogger(Config.class);
	
	/**
	 * Project root 
	 * @param dir
	 */
	public static void processLog (String dir) {
		if (dir == null) {
			dir = System.getProperty("user.dir");
			
		}
		File file = new File(dir);
		if (!file.isDirectory()) {
			Logger.error(file.getAbsolutePath() + " is not a directory");
			return;
		}
		
		Config.rootDir = file.getAbsolutePath();
		
		try {
			ConfigParser.parseFromDir(dir);
		} catch (Exception e) {
			Logger.warn("Exception in parsing configuration: " +
				e.getMessage());
		}
		
		Config.log();
	}
	
	public static void  log () {
		Logger.info("Project root: " + Config.rootDir);
		Logger.info("type: " + Config.projectType);
		Logger.info("srcdirs: " + Config.srcdirs);
		Logger.info("database: " + Config.DB.type);
	}
}
