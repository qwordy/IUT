package cn.edu.sjtu.stap.command;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

import cn.edu.sjtu.stap.Config;
import cn.edu.sjtu.stap.Logger;
import cn.edu.sjtu.stap.db.Database;
import cn.edu.sjtu.stap.path.PathResolver;

import com.beust.jcommander.Parameter;
import com.beust.jcommander.Parameters;

@Parameters(commandDescription = "Update database using execution path.")
public class UpdateCommand implements ICommand {

	@Parameter(arity = 1, description = "project directory")
	List<String> dirs;

	@Override
	public void process() {
		if (dirs == null) {
			Config.processLog(null);
		} else {
			Config.processLog(dirs.get(0));
		}

		Database db = new Database();
		if (db.getConnection() == null) {
			Logger.error("Fail to connect to database.");
		} else {
			String logdirPath = FilenameUtils.concat(Config.rootDir, "iutlogs");
			File logfile = new File(logdirPath);
			try {
				List<String> lines = FileUtils.readLines(logfile);
				new PathResolver(db, Config.project, lines);

				db.close();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}

}
