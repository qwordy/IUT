package cn.edu.sjtu.stap.db;

public interface IEntity {

	public String createStmt ();
}
