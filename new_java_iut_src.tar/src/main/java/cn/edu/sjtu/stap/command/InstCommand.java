package cn.edu.sjtu.stap.command;


import java.util.List;

import cn.edu.sjtu.stap.Config;
import cn.edu.sjtu.stap.Logger;
import cn.edu.sjtu.stap.inst.CopyFileWalker;

import com.beust.jcommander.Parameter;
import com.beust.jcommander.Parameters;

@Parameters(commandDescription = "Instrument sources.")
public class InstCommand implements ICommand {
	
	@Parameter(arity = 1, description = "the project directory to be instrumented")
	List<String> dirs;
	
	public void process() {
		if (dirs == null) {
			Config.processLog(null);
		} else {
			Config.processLog(dirs.get(0));
		}
		
		if (Config.srcdirs != null) {
			new CopyFileWalker(Config.rootDir, Config.srcdirs);
		} else {
			Logger.warn("Source folder of instrumenting is not configured!");
		}
		//FileUtils.copyDirectory(Config.rootDir, destDir, filter);
		

	}
}
