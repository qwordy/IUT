package cn.edu.sjtu.stap.differ;

public class DifferException extends Exception {
	
	private static final long serialVersionUID = -168853405829661816L;

	public DifferException (String message) {
		super(message);
	}
}
