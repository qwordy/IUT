package cn.edu.sjtu.stap.db.entity;

public class Project {

}
