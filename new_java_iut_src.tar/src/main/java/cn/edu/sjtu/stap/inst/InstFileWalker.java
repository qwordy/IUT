package cn.edu.sjtu.stap.inst;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Stack;

import org.apache.commons.io.DirectoryWalker;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

import cn.edu.sjtu.stap.Logger;

public class InstFileWalker extends DirectoryWalker {

	String currentBasePath;
	String outputPath;
	File rootDir;
	Stack<String> dirStack;

	@Override
	protected void handleDirectoryStart(File directory, int depth,
			Collection results) {
		this.dirStack.push(directory.getName());
		this.currentBasePath = this._getCurrentBasePath();
	}

	@Override
	protected void handleDirectoryEnd(File directory, int depth,
			Collection results) {
		this.dirStack.pop();
		this.currentBasePath = this._getCurrentBasePath();
	}

	private String _getCurrentBasePath() {
		String currentBasePath = ".";
		for (int i = 1; i < this.dirStack.size(); i++) {
			currentBasePath = FilenameUtils.concat(currentBasePath,
					dirStack.get(i));
		}
		return currentBasePath;
	}

	private void createLoggerFile() throws Exception {

		try {
			File outputPackage = new File(outputPath, "cn/edu/sjtu/iut");

			FileUtils.forceMkdir(outputPackage);
			File loggerFile = new File(outputPackage, "IutLogger.java");
			InputStream is = getClass().getResourceAsStream("/IutLogger.txt");

			// if (is != null) {
			FileUtils.copyInputStreamToFile(is, loggerFile);

		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Fail to create IutLogger.java! " + "["
					+ e.getClass().toString() + "]" + e.getMessage());
		}
	}

	public InstFileWalker(File rootDir, String outputPath) {
		super();
		this.currentBasePath = "";
		this.rootDir = rootDir;
		this.outputPath = outputPath;
		this.dirStack = new Stack<String>();

		System.out.println(this.outputPath);
		List<Object> results = new ArrayList<Object>();
		try {
			createLoggerFile();
			walk(rootDir, results);
		} catch (IOException e) {
			e.printStackTrace();
			Logger.error(e.getMessage());
		} catch (Exception e) {
			Logger.error(e.getMessage());
		}
	}

	@Override
	protected boolean handleDirectory(File directory, int depth,
			Collection results) {
		try {

			File newDir = null;
			if (depth != 0) {
				newDir = new File(FilenameUtils.concat(this.outputPath,
						this.currentBasePath), directory.getName());
			} else {
				newDir = new File(this.outputPath);
			}
			if (!newDir.exists()) {
				FileUtils.forceMkdir(newDir);
				Logger.info("Making dir: " + newDir.getCanonicalPath());
			}

			return true;
		} catch (IOException e) {
			Logger.error(e.getMessage());
			System.exit(-1);
		}

		return false;
	}

	/*
	 * @Override protected boolean handleDirectory(File directory, int depth,
	 * Collection results) { return true; }
	 */

	@Override
	protected void handleFile(File file, int depth, Collection results) {
		try {

			String fileName = file.getName();
			File outputFile = new File(FilenameUtils.concat(this.outputPath,
					this.currentBasePath), fileName);
			if (fileName != null && fileName.endsWith(".java")) {
				Logger.info("Instrumenting " + file.getCanonicalPath());
				Instrument inst = new Instrument();
				String source = FileUtils.readFileToString(file);
				String instedSource = inst.instSource(source);
				FileUtils.writeStringToFile(outputFile, instedSource);
			} else {
				FileUtils.copyFile(file, outputFile, true);
				Logger.debug("Copying " + file.getCanonicalPath());

			}

		} catch (Exception e) {
			e.printStackTrace();
			Logger.error("Instrumenting " + file.getName());
			System.exit(-1);
		}
	}
}
