package cn.edu.sjtu.stap.differ;

public abstract class DifferUnit {
	
	public DifferUnit () {

	}
}
