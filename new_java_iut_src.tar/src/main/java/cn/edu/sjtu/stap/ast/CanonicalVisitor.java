package cn.edu.sjtu.stap.ast;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.AbstractTypeDeclaration;
import org.eclipse.jdt.core.dom.BlockComment;
import org.eclipse.jdt.core.dom.EnumConstantDeclaration;
import org.eclipse.jdt.core.dom.Javadoc;
import org.eclipse.jdt.core.dom.LineComment;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import cn.edu.sjtu.stap.Config;
import cn.edu.sjtu.stap.Util;

public class CanonicalVisitor extends ASTVisitor {
	
	Stack<String> typeStack;
	String currentType, packageName;
	List<XMethodDeclaration> methodIds;
	
	public List<XMethodDeclaration> getMethodIds() {
		return this.methodIds;
	}
	
	public CanonicalVisitor (String packageName) {
		super(false);
		this.packageName = packageName;
		this.typeStack = new Stack<String>();
		this.methodIds = new ArrayList<XMethodDeclaration>();
	}
	
	private String _getCurrentType () {

		String type = "";
		for (int i = 0; i < this.typeStack.size(); i++) {
			type += this.typeStack.get(i) + ".";
		}
		return type;
	}
	
	public void preVisit(ASTNode node) {
		if (node instanceof AbstractTypeDeclaration) {
			this.typeStack.push(((AbstractTypeDeclaration) node).getName().toString());
			this.currentType = this._getCurrentType();
		} else if (node instanceof EnumConstantDeclaration) {
			this.typeStack.push(((EnumConstantDeclaration) node).getName().toString());
			this.currentType = this._getCurrentType();
		}
	}
	
	public void postVisit(ASTNode node) {
		if (node instanceof AbstractTypeDeclaration
				|| node instanceof EnumConstantDeclaration) {
			this.typeStack.pop();
			this.currentType = this._getCurrentType();
		}
	}
	
	
	public boolean visit(TypeDeclaration node) {
		if (!node.isInterface()) {
			MethodDeclaration[] methodDecls = node.getMethods();
			
			int methodLength = methodDecls.length;
			for (int i = 0; i < methodLength; i++) {
				MethodDeclaration methodDecl = methodDecls[i];
				
				// TODO merge code with code instrumenting
				StringBuilder sb = new StringBuilder();
				// sb.append(Config.instPrefix);
				sb.append(this.packageName).append(Config.instSeperator);
				sb.append(this.currentType).append(Config.instSeperator);
				sb.append(Util.getMethodSignature(methodDecl));
				
				this.methodIds.add(new XMethodDeclaration(methodDecl,
						sb.toString()));
			}
		}
		return true;
	}
	
	public boolean visit (Javadoc node) {
		node.delete();
		return false;
	}
	
	public boolean visit (BlockComment node) {
		node.delete();
		return false;
	}
	
	public boolean visit (LineComment node) {
		node.delete();
		return false;
		
	}
}
