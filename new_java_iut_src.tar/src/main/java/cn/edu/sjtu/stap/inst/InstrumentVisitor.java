package cn.edu.sjtu.stap.inst;

import java.util.List;
import java.util.Stack;

import org.eclipse.jdt.core.dom.AbstractTypeDeclaration;
import org.eclipse.jdt.core.dom.Assignment;
import org.eclipse.jdt.core.dom.EnumConstantDeclaration;
import org.eclipse.jdt.core.dom.EnumDeclaration;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.Initializer;
import org.eclipse.jdt.core.dom.Modifier;
import org.eclipse.jdt.core.dom.PrefixExpression;
import org.eclipse.jdt.core.dom.PrimitiveType;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.ThisExpression;
import org.eclipse.jdt.core.dom.Type;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.FieldAccess;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.StringLiteral;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.TypeLiteral;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
import org.eclipse.jdt.core.dom.PrefixExpression.Operator;

import cn.edu.sjtu.stap.Config;
import cn.edu.sjtu.stap.Util;

public class InstrumentVisitor extends ASTVisitor {
	
	

	ASTParser parser;
	String currentType, packageName;
	Stack<String> typeStack;
	static final String METHOD_PREFIX = "__IUT__";

	public InstrumentVisitor(String packageName) {
		super();
		
		currentType = "";
		this.packageName = packageName;
		this.typeStack = new Stack<String>();
// System.setp
		// parser.setSource(source.toCharArray()););
	}
	
	
	private String _getCurrentType () {

		String type = "";
		for (int i = 0; i < this.typeStack.size(); i++) {
			type += this.typeStack.get(i) + ".";
		}
		return type;
	}
	
	public void preVisit(ASTNode node) {
		if (node instanceof AbstractTypeDeclaration) {
			this.typeStack.push(((AbstractTypeDeclaration) node).getName().toString());
			this.currentType = this._getCurrentType();
		} else if (node instanceof EnumConstantDeclaration) {
			this.typeStack.push(((EnumConstantDeclaration) node).getName().toString());
			this.currentType = this._getCurrentType();
		}
	}
	
	public void postVisit(ASTNode node) {
		if (node instanceof AbstractTypeDeclaration
				|| node instanceof EnumConstantDeclaration) {
			this.typeStack.pop();
			this.currentType = this._getCurrentType();
		}
	}
	

	public boolean visit(TypeDeclaration node) {

		if (!node.isInterface()) {
			// System.out.print(currentType);
			
			MethodDeclaration[] methodDecls = node.getMethods();
		
			int methodLength = methodDecls.length;
			AST ast = node.getAST();

			// List bodyDecls = node.bodyDeclarations();
			// methodCount = 0;

			for (int i = 0; i < methodLength; i++) {
				Type boolType = ast.newPrimitiveType(PrimitiveType.BOOLEAN);
				Modifier privateModifier = ast
						.newModifier(Modifier.ModifierKeyword.PRIVATE_KEYWORD);
				VariableDeclarationFragment vdf = ast
						.newVariableDeclarationFragment();
				vdf.setName(ast.newSimpleName(METHOD_PREFIX + i));
				vdf.setInitializer(ast.newBooleanLiteral(false));
				// vdf.set
				FieldDeclaration fDecl = ast.newFieldDeclaration(vdf);
				fDecl.setType(boolType);
				fDecl.modifiers().add(privateModifier);
				fDecl.modifiers().add(ast.newModifier(Modifier.ModifierKeyword.STATIC_KEYWORD));
				// bodyDecls.add(fDecl);
				this.reriteMethod(methodDecls[i], i);
				// new Type();
				// fDecl.setType(PrimitiveType.BOOLEAN);
			}
		}

		return true;
	}

	private static final String[] loggerAccessor = { "IutLogger", "iut",
			"sjtu", "edu", "cn" };
	
	/*
	private Expression staticAccess(String field) {
		int stackSize = this.typeStack.size();
		for (int i = 0; i < stackSize; i++) {
			
		}
	}
	*/

	private Expression nestedAccess(String[] fields, int index, AST ast) {
		if (index >= fields.length - 1) {
			// return ast.newSimpleName(fields[0]);
			return ast.newSimpleName(fields[index]);
		} else {
			FieldAccess fa = ast.newFieldAccess();
			fa.setName(ast.newSimpleName(fields[index]));
			fa.setExpression(nestedAccess(fields, index + 1, ast));
			return fa;
		}
	}

	public void reriteMethod(MethodDeclaration node, int id) {
		Block body = node.getBody();
		AST ast = node.getAST();
		
		if (body == null) {
			return;
		}

		StringBuilder sb = new StringBuilder();
		// sb.append(Config.instPrefix);
		sb.append(this.packageName).append(Config.instSeperator);
		sb.append(this.currentType).append(Config.instSeperator);
		sb.append(Util.getMethodSignature(node));

		String logContent = sb.toString();

		try {
			// if (!this.__IUT__XX) {
			// logxxx
			// this._IUT__XX = true
			// }

			// predicate
			/*
			ThisExpression thisExpr = ast.newThisExpression();
			FieldAccess faThis = ast.newFieldAccess();
			faThis.setName(ast.newSimpleName(this.METHOD_PREFIX + id));
			faThis.setExpression(thisExpr);

			PrefixExpression notExpr = ast.newPrefixExpression();
			notExpr.setOperator(Operator.NOT);
			notExpr.setOperand(faThis);

			IfStatement ifStmt = ast.newIfStatement();
			ifStmt.setExpression(notExpr);
			*/

			// logger invoke
			MethodInvocation mi = ast.newMethodInvocation();
			StringLiteral info = ast.newStringLiteral();
			info.setLiteralValue(logContent);
			FieldAccess getInstance = (FieldAccess) nestedAccess(
					loggerAccessor, 0, ast);

			mi.setName(ast.newSimpleName("getLogger"));
			mi.setExpression(getInstance);

			MethodInvocation miLog = ast.newMethodInvocation();
			miLog.setName(ast.newSimpleName("log"));
			miLog.setExpression(mi);
			miLog.arguments().add(info);
			// mi.setExpression(info);

			// set
			/*
			Assignment assign = ast.newAssignment();
			// Initializer initializer = ast.new
			ThisExpression thisExpr1 = ast.newThisExpression();
			FieldAccess faThis1 = ast.newFieldAccess();
			faThis1.setExpression(thisExpr1);
			faThis1.setName(ast.newSimpleName(this.METHOD_PREFIX + id));
			assign.setLeftHandSide(faThis1);
			assign.setRightHandSide(ast.newBooleanLiteral(true));
			*/
			Block blk = ast.newBlock();

			blk.statements().add(ast.newExpressionStatement(miLog));
			//blk.statements().add(ast.newExpressionStatement(assign));

			//ifStmt.setThenStatement(blk);
			
			

			if (body != null) {
				// System.out.println(logContent);
				// System.out.println(node.toString());
				
				if (node.isConstructor()) {
					int count = 0;
					List<?> stmts = body.statements();
					for (Object obj : stmts) {
						Statement stmt = (Statement)obj;
						String content = stmt.toString().trim();
						if (content.startsWith("super") || content.startsWith("this")) {
							count ++;
						} else {
							break;
						}
						
					}
					body.statements().add(count, blk);
				} else {
					body.statements().add(0, blk);
				}
			}
			// ast.new
		} catch (Exception e) {
			e.printStackTrace();
		}

		// System.out.println(node);
	}
}
