package cn.edu.sjtu.stap.ast;

public class XTypeDeclaration {

}
