package cn.edu.sjtu.stap.path;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.sun.crypto.provider.RSACipher;

import cn.edu.sjtu.stap.Config;
import cn.edu.sjtu.stap.db.Database;
import cn.edu.sjtu.stap.db.entity.Method;

/**
 * Parse the execution path file & update database
 * 
 * @author yejiabin
 *
 */

public class PathResolver {

	String project;

	/**
	 * TODO migrate to dababase class 
	 * testId path ...
	 * 
	 * @param project
	 * @param fileName
	 * @throws Exception
	 */

	public PathResolver(Database db, String project, 
			List<String> lines) {
		this.project = project;
		// this.testCase = testCase;

		//List<Method> methods = new ArrayList<Method>();
		//Set<String> testcases = new HashSet<String>();
		Map<String, List<Method>> map = new HashMap<String, List<Method>>();
		int ln = 0;
		for (String line : lines) {
			String[] segs = line.split(":");
			
			if (segs.length == 4) {
				String testCase = segs[0];
				List<Method> m = map.get(testCase);
				if (m != null) {
					m.add(new Method(segs[1], segs[2], segs[3]));
				} else {
					List<Method> newList = new ArrayList<Method>();
					newList.add(new Method(segs[1], segs[2], segs[3]));
					map.put(testCase, newList);
				}
				ln ++;
			} else {
				System.out.println("Some line is broken!");
			}
		}
		System.out.println(ln + " lines");

		// this.testCase = testCase;

		try {
			Connection conn = db.getConnection();
			// conn.setAutoCommit(false);

			// Statement stmt = conn.createStatement();

			int projectId;
			// ResultSet rs = stmt.executeQuery("SELECT * FROM Project");

			// check if project existence
			PreparedStatement pProjectExistence = conn
					.prepareStatement("SELECT * FROM Project WHERE name = ? LIMIT 1");
			pProjectExistence.setString(1, project);
			ResultSet rsProjectCount = pProjectExistence.executeQuery();
			if (rsProjectCount.next()) {
				projectId = rsProjectCount.getInt(1);
			} else {
				PreparedStatement pCreateProject = conn.prepareStatement(
						"INSERT INTO Project VALUES (NULL, ?, NULL)",
						Statement.RETURN_GENERATED_KEYS);
				pCreateProject.setString(1, project);
				pCreateProject.executeUpdate();
				ResultSet rs = pCreateProject.getGeneratedKeys();
				rs.next();
				projectId = rs.getInt(1);
			}

			// always create a new test case
			int count = 0;
			for (Map.Entry<String, List<Method>> e : map.entrySet()) {
				String testCase = e.getKey();
				int testCaseId;
				
				
				
				PreparedStatement pTestCaseExistence0 = conn
						.prepareStatement("SELECT * FROM TestCase WHERE name = ?");
				pTestCaseExistence0.setString(1, testCase);
				ResultSet rsTestCase = pTestCaseExistence0.executeQuery();
				if (rsTestCase.next()) {
					testCaseId = rsTestCase.getInt(1);
					PreparedStatement ps = conn.prepareStatement("DELETE FROM MethodMap WHERE test_case = ?");
					ps.setInt(1, testCaseId);
					ps.executeUpdate();
					
					PreparedStatement pTestCaseExistence = conn
							.prepareStatement("DELETE FROM TestCase WHERE name = ?");
					pTestCaseExistence.setString(1, testCase);
					pTestCaseExistence.executeUpdate();
				}
		

				PreparedStatement pCreateTestCase = conn.prepareStatement(
						"INSERT INTO TestCase VALUES (NULL, ?, NULL, ?)",
						Statement.RETURN_GENERATED_KEYS);
				pCreateTestCase.setString(1, testCase);
				pCreateTestCase.setInt(2, projectId);

				pCreateTestCase.executeUpdate();
				ResultSet rs = pCreateTestCase.getGeneratedKeys();
				rs.next();
				testCaseId = rs.getInt(1);
				
				// System.out.println(testCase + " " + testCaseId + "  is in processing");

				// conn.setAutoCommit(false);
				int precent = 0; 
				int last = 0;
				// conn.
				// StringBuilder sb = new StringBuilder();
				// sb.append("INSERT INTO MethodMap VALUES ");
				PreparedStatement ps = conn
						.prepareStatement("INSERT INTO MethodMap VALUES (?, ?)");
				Set<String> ms = new HashSet<String>();
				for (Method m : e.getValue()) {
					// sb.append("('").append(m.toString()).append("',").append(testCaseId).append("),");
					String mstr = m.toString();
					if (ms.contains(mstr)) {
						continue;
					}
					ps.setString(1, mstr);
					ps.setInt(2, testCaseId);
					ps.addBatch();
					// ps.clearParameters();
					// System.out.print("batching " + count + "\r");
					// ps.executeUpdate();
					ms.add(mstr);
					count ++;
					
				}
				
				ps.executeBatch();
				
				// System.out.println(sb.substring(0, sb.length() -1).toString());
				// String sql = sb.substring(0, sb.length() -1).toString();
				// System.out.println(sql);
				
				// Statement stmt = conn.createStatement();
				//stmt.setEscapeProcessing(false);
				//stmt.
				// stmt.
				// stmt.executeUpdate(sql);
				//conn.prepareStatement(sb.substring(0, sb.length() -1).toString());
				precent = (int) (((double)count/(double)ln)*1000);
				if (precent > last) {
					last = precent;
					System.out.print((double)precent/10.0 + " %\r");
				}
				
				//conn.commit();
				//conn.setAutoCommit(true);
				// System.gc();
				// System.out.println(count + " has been commited ");
			}
			
			

			// conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
