package cn.edu.sjtu.stap.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.sqlite.JDBC;

import cn.edu.sjtu.stap.Config;
import cn.edu.sjtu.stap.Logger;

public class Database {
	Connection conn;

	public Connection getConnection() {
		return conn;
	}

	public Database() {
		conn = null;

		StringBuilder sb = new StringBuilder();
		sb.append("jdbc:").append(Config.DB.type).append(":")
				.append(Config.DB.host);

		try {
			Class.forName("org.sqlite.JDBC");
			conn = DriverManager.getConnection(sb.toString());

		} catch (SQLException ex) {
			// handle any errors
			Logger.error("SQLException: " + ex.getMessage());
			Logger.error("SQLState: " + ex.getSQLState());
			Logger.error("VendorError: " + ex.getErrorCode());
			ex.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public Set<String> getAffected(List<String> affected) {
		Set<String> testCases = new HashSet<String>();
		try {
			//conn.setAutoCommit(false);
			for (String m : affected) {
				PreparedStatement pTestCase = this.conn
						.prepareStatement("SELECT name FROM (SELECT test_case FROM methodMap testCase WHERE signature = ? ) AS t JOIN testcase ON (t.test_case = testcase.id); ");
				pTestCase.setString(1, m);
				ResultSet rs = pTestCase.executeQuery();
				while(rs.next()) {
					String testName = rs.getString(1);
					StringBuilder sb = new StringBuilder(testName);
					sb.replace(testName.lastIndexOf("."), testName.lastIndexOf(".") + 1, "#" );
					
					testCases.add(sb.toString());
				}
			}
			//conn.commit();
			// conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return testCases;
	}

	public void close() throws Exception {
		conn.close();
	}
}
