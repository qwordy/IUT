package cn.edu.sjtu.stap.command;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;

import cn.edu.sjtu.stap.Config;
import cn.edu.sjtu.stap.Logger;
import cn.edu.sjtu.stap.db.Database;
import cn.edu.sjtu.stap.differ.DifferResult;
import cn.edu.sjtu.stap.differ.FileDiffer;

import com.beust.jcommander.Parameter;
import com.beust.jcommander.Parameters;

@Parameters(commandDescription = "Calculates differences between two projects in method level.")
public class DiffCommand implements ICommand {

	@Parameter(arity = 2, description = "<old> <new> directories")
	List<String> dirs;
	
	

	public void process() {
		if (dirs != null && dirs.size() == 2) {
			Config.processLog(dirs.get(0));
			try {
				Database db = new Database();
				List<String> lines = new ArrayList<String>();
				for (String srcdir : Config.srcdirs) {
					FileDiffer FD = new FileDiffer();
					try {
						// System.out.println("diffing " + dirs.get(0) + ", " + dirs.get(1));
						DifferResult dc = FD.diff(dirs.get(0), dirs.get(1), srcdir);
						System.out.print(dc);
						for (String testcase : db.getAffected(dc.getAffectedMethods())) {
							System.out.println(testcase + " is affected");
							lines.add(testcase);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}	
					
				}
				FileUtils.writeLines(new File("affected-test-case"), lines, false);
				db.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			Logger.error("Please specifiy two directories");
		}
	}
}
