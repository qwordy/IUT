package cn.edu.sjtu.stap;

// import org.pmw.tinylog.Logger;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


public class ConfigParser {

	public static void parseFromDir (String dir) throws Exception {
		File configFile = new File(dir + "/iut.json");
		if (configFile.isFile()) {
			ConfigParser.parse(Util.fileToString(configFile));
		} else {
			Logger.debug(configFile.toString() + 
					" not found, using default config instead.");
		}
		
	}
	
	public static void parse (String content) throws Exception {
		// JsonFactory factory = new JsonFactory();

		// JsonParser jp = factory.createParser(content);
		// ConfigCls config = jp.readValueAs(ConfigCls.class);
		ObjectMapper mapper = new ObjectMapper();
		JsonNode root = mapper.readTree(content);
		// jp.
		//JsonObject root = JsonObject.readFrom(content);
		
		// String type = root.getString("type", "gradle");
		Config.projectType = "gradle";
	
		//Map<String, String> dbConfig = config.getDatabase();
		
		JsonNode srcdirs = root.get("srcdirs");
		if (srcdirs != null) {
			List<String> srcList = new ArrayList<String>();
			for (JsonNode node : root.path("srcdirs")) {
				srcList.add(node.asText());
			}
			Config.srcdirs = srcList;
		}
		
        
		Config.project = root.get("project").asText();
        if (Config.project == null) 
            Config.project = (Config.rootDir);
		JsonNode dbConfig = root.get("database");
		//JsonValue dbConfig = root.get("database");
		if (dbConfig != null) {
			// JsonObject db = dbConfig.asObject();
			Config.DB.db = dbConfig.get("db").asText();
			Config.DB.host = dbConfig.get("host").asText();
			Config.DB.password = dbConfig.get("password").asText();
			Config.DB.username = dbConfig.get("username").asText();
			Config.DB.type = dbConfig.get("type").asText();
		}
		
	}
}
