package cn.edu.sjtu.stap.command;

import com.beust.jcommander.Parameter;

public class MainCommand {

	@Parameter(help = true, names = "-help", description = "display this message")
	public Boolean help;
	
	@Parameter(names = "-version", description = "version")
	public String version;
	
	@Parameter(names = "-log" , description = "Level of verbosity")
	public Integer verbose;
	
}
