package iut;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import cn.edu.sjtu.stap.inst.Instrument;

public class TestInstrument {

	
	String filterContent ;
	Instrument instrumenter;
	
	@Before
	public void setUp() throws Exception {
		// getClass().getResource("Filter.java");
		InputStream is = getClass().getResourceAsStream("/Criteral.java");
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();
		String line;
		while((line = reader.readLine()) != null) {
			sb.append(line).append('\n');
		}
		filterContent = sb.toString();
		reader.close();
		
		instrumenter = new Instrument();
	}
	
	@Test
	public void testFileLoaded() {
		Assert.assertTrue(filterContent.length() > 0);
	}

	@Test
	public void test() {
		String output = instrumenter.instSource(filterContent);
		Assert.assertNotEquals(filterContent, output);
		System.out.println(output);
	}

}
