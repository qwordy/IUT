PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE "Method" (
  "id" integer PRIMARY KEY,
  "sig" varchar(128) NOT NULL,
  "package" varchar(128) DEFAULT NULL,
  "class" varchar(128) DEFAULT NULL,
  "project" integer NOT NULL,
  CONSTRAINT "fk_project" FOREIGN KEY ("project") REFERENCES "Project" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE TABLE "MethodMap" (
  "signature" varchar(128) NOT NULL,
  "test_case" INTEGER NOT NULL,
  PRIMARY KEY ("signature","test_case"),
  CONSTRAINT "fk_test_case" FOREIGN KEY ("test_case") REFERENCES "TestCase" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

create table "Project" (
  "id" INTEGER PRIMARY KEY,
  "name" varchar(128) NOT NULL UNIQUE,
  "description" varchar(128) DEFAULT NULL
);

CREATE TABLE "TestCase" (
  "id" INTEGER PRIMARY KEY,
  "name" varchar(128) NOT NULL,
  "description" varchar(128) DEFAULT NULL,
  "project" INTEGER NOT NULL,
  CONSTRAINT "fk_tc_project" FOREIGN KEY ("project") REFERENCES "Project" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE INDEX "MethodMap_fk_test_case_idx" ON "MethodMap" ("test_case");
CREATE INDEX "TestCase_name_UNIQUE" ON "TestCase" ("name");
CREATE INDEX "TestCase_fk_project_idx" ON "TestCase" ("project");
CREATE INDEX "Project_name_UNIQUE" ON "Project" ("name");
CREATE INDEX "Method_sig_UNIQUE" ON "Method" ("sig");
CREATE INDEX "Method_fk_project_idx" ON "Method" ("project");
COMMIT;
