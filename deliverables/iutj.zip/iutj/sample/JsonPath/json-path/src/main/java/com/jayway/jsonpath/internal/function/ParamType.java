package com.jayway.jsonpath.internal.function;

/**
 * Created by mgreenwood on 12/11/15.
 */
public enum ParamType {
    JSON,
    PATH
}
