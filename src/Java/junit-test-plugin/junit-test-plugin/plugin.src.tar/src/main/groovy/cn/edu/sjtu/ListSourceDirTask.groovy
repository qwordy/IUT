package cn.edu.sjtu;
import org.gradle.api.Project
import org.gradle.api.DefaultTask
import org.gradle.api.tasks.TaskAction
import org.gradle.api.tasks.SourceSetContainer
import org.gradle.api.tasks.SourceSet
import java.util.Set
import java.io.File

class ListSourceDirTask extends DefaultTask{
    @TaskAction    
    def list() {		
        Project project = getProject()        
        //println "projectName: " + project.getName()		
        list(project, project)		
        project.getSubprojects().each { sub ->
            list(sub, project)
        }   
     }	
     // list relative "main/java" path to root project 
     def list(Project p, Project root) {		
         if(p.getPluginManager().hasPlugin("java")) {			
             //println project.getName() + " has java plugin"			
             def sources = p.getProperties().get("sourceSets")			
             sources.each { sourceSet ->
                if(!sourceSet.getName().equals("test")){ 
                    // exclude test java					
                    def srcs = sourceSet.getJava().getSrcDirs()
                    srcs.each { src ->
                        println root.relativePath(src.getCanonicalPath())
                    }
                }
            }		
        } 
    }	
}
