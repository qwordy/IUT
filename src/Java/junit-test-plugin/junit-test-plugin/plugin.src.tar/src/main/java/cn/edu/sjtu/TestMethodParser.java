package cn.edu.sjtu;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.io.filefilter.RegexFileFilter;
import org.apache.commons.lang3.SystemUtils;

import org.eclipse.jdt.core.dom.*;

/**
 * @author YuPeng
 *
 */
public class TestMethodParser {
	
	private List<TestMethod> testMethods = new ArrayList<TestMethod>();
	private int methodIndex = 0;
	
	/**
	 * to list all test method in the dir and sub dirs
	 * @param dir
	 */
	public void listTests(Collection<File> files, boolean quiet, String pathPrefix) {
		testMethods.clear();
		methodIndex = 0;

		Iterator<File> iterator = files.iterator();
		while (iterator.hasNext()) {
			File file = (File) iterator.next();
			try {
				if(!file.getCanonicalPath().startsWith(pathPrefix)) continue;
			} catch (Exception e) {
				continue;
			}
			
			ASTParser parser = ASTParser.newParser(AST.JLS3);
			parser.setSource(readFileToCharArray(file));
			CompilationUnit root = (CompilationUnit) parser.createAST(null);
			CompilationUnitVisitor visitor = new CompilationUnitVisitor();
			root.accept(visitor);
			
			for (TestMethod method : visitor.getTestMethods()) {
				method.setId(methodIndex++);
				// System.out.println("\t" + method.getPackageName() + "." + method.getClassName() + "." + method.getMethodName());
                testMethods.add(method);
			}
		}
		
		//meaningless
		// if(!quiet) System.out.println();
	}

	private char[] readFileToCharArray(File file){
		StringBuilder fileData = new StringBuilder(1000);
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(file));
			char[] buf = new char[10];
			int numRead = 0;
			while ((numRead = reader.read(buf)) != -1) {
				String readData = String.valueOf(buf, 0, numRead);
				fileData.append(readData);
				buf = new char[1024];
			}
			reader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return  fileData.toString().toCharArray();	
	}

	public List<TestMethod> getTestMethods() {
		return testMethods;
	}

	public void setTestMethods(List<TestMethod> testMethods) {
		this.testMethods = testMethods;
	}
    
    
}
