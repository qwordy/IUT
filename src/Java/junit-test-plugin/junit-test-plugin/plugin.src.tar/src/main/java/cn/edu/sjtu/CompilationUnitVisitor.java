/**
 * 
 */
package cn.edu.sjtu;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.jdt.core.dom.*;

/**
 * @author Yu Peng
 *
 */
class CompilationUnitVisitor extends ASTVisitor {
	private String packageName;
	private String className;
	private String methodName;
	private String annotationTypeName;
	private List<TestMethod> testMethods;
	private boolean newTestAnnotation;
	
	public CompilationUnitVisitor() {
		packageName = "";
		className = "";
		methodName = "";
		annotationTypeName = "";
		testMethods = new ArrayList<TestMethod>();
		newTestAnnotation = false;
	}
	
	@Override
	public boolean visit(CompilationUnit node) {
		if (node.getPackage() != null) {
			node.getPackage().accept(this);
		}
		for (Iterator it = node.types().iterator(); it.hasNext(); ) {
			AbstractTypeDeclaration d = (AbstractTypeDeclaration) it.next();
			d.accept(this);
		}
		return false;
	}
	
	@Override
	public boolean visit(PackageDeclaration node) {
		this.packageName = node.getName().toString();
		return false;
	}
	
	private String getClassName(MethodDeclaration node) {
		ASTNode parent = node.getParent();
		while(!(parent instanceof AnnotationTypeDeclaration || parent instanceof TypeDeclaration)){
			parent = parent.getParent();
		}
		
		if(parent instanceof AnnotationTypeDeclaration) {
			className = ((AnnotationTypeDeclaration)parent).getName().toString();
		}
		else {
			className = ((TypeDeclaration)parent).getName().toString();
		}
		return className;
	}
	
	@Override
	public boolean visit(MethodDeclaration node) {
		newTestAnnotation = false;
		
		for (Iterator it = node.modifiers().iterator(); it.hasNext(); ) {
			ASTNode p = (ASTNode) it.next();
			p.accept(this);
		}
		
		methodName = node.getName().toString();
		if(newTestAnnotation) {
			String className = getClassName(node);
			testMethods.add(new TestMethod(0, packageName, className, methodName));
		}
		return false;
	}
	
	@Override
	public boolean visit(MarkerAnnotation node) {
		annotationTypeName = node.getTypeName().toString();
		if("Test".equals(annotationTypeName)){
			newTestAnnotation = true;
		}
		return false;
	}
	
	@Override
	public boolean visit(NormalAnnotation node) {
		annotationTypeName = node.getTypeName().toString();
		if("Test".equals(annotationTypeName)){
			newTestAnnotation = true;
		}
		return false;
	}
	
	@Override
	public boolean visit(SingleMemberAnnotation node) {
		annotationTypeName = node.getTypeName().toString();
		if("Test".equals(annotationTypeName)){
			newTestAnnotation = true;
		}
		return false;
	}
	
	public List<TestMethod> getTestMethods(){
		return testMethods;
	}
}
