package cn.edu.sjtu
import org.gradle.api.Project
import org.gradle.api.DefaultTask
import org.gradle.api.tasks.TaskAction
import org.gradle.api.tasks.SourceSetContainer
import org.gradle.api.tasks.SourceSet
import java.util.Set
import java.io.File
import com.eclipsesource.json.*

/**
 *
 * list all junit test cases, with its classpath and all of its test methods
 * for all (sub)projects but not recursively
 * 
 */


class ListTestCaseTask extends DefaultTask {

	@TaskAction
	def list() {
		Project project = getProject()
		//println "projectName: " + project.getName()
		list(project, project)
        project.getSubprojects().each { sub ->
			list(sub, project)		
        }
	}
	
	// list all junit test cases, with its classpath and all of its test methods
	def list(Project p, Project root) {
		if(!p.getPluginManager().hasPlugin("java")) {
            return 
        }
        def sources = p.property("sourceSets")
        sources.each { sourceSet ->
            if(sourceSet.getName().equals("test")){ // for test java
                def srcs = sourceSet.getJava().getSrcDirs()
                srcs.each { src ->

                    TestMethodParser parser = new TestMethodParser();
                    parser.listTests(sourceSet.getJava().getFiles(), false, src.getCanonicalPath());
                    def tms = parser.getTestMethods();
                    
                     //  println "******  classpath for test cases in " + root.relativePath(src.getCanonicalPath()) + "\n"
                    def files =  sourceSet.getRuntimeClasspath()
                    def cp = files.inject("") { base, acc ->
                        "${base}:${acc.getCanonicalPath()}"
                    }
                    println cp
                    tms.each { tm ->
                        println tm
                    }
                }
           }
       }
    }
}
