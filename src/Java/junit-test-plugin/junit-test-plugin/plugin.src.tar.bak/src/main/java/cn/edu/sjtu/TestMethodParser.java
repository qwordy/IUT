package cn.edu.sjtu;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.io.filefilter.RegexFileFilter;
import org.apache.commons.lang3.SystemUtils;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseException;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.BodyDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.expr.AnnotationExpr;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

/**
 *
 */
public class TestMethodParser {
	
	private List<TestMethod> testMethods = new ArrayList<TestMethod>();
	private int methodIndex = 0;
	
	/**
	 * to list all test method in the dir and sub dirs
	 * @param dir
	 */
	public void listTests(Collection<File> files, boolean quiet, String pathPrefix) {
		testMethods.clear();
		methodIndex = 0;

		Iterator<File> iterator = files.iterator();
		while (iterator.hasNext()) {
			File file = (File) iterator.next();
			try {
				if(!file.getCanonicalPath().startsWith(pathPrefix)) continue;
			} catch (Exception e) {
				continue;
			}
			
			FileInputStream in = null;
	        CompilationUnit cu = null;
			try {
				in = new FileInputStream(file);
	            // parse the file
	            cu = JavaParser.parse(in);
	        } catch (FileNotFoundException e) {

			} catch (ParseException e) {

			} finally {
	            if(in!=null)
					try {
						in.close();
					} catch (IOException e) {

					}
	        }

	        // visit and print the methods names
			if(cu!=null){
				//new MethodVisitor().visit(cu, null);
				listMethods(cu, quiet);
			}
		}
		
	}
	
	/**
	 * list all test method in a java file
	 * @param cu
	 */
	private void listMethods(CompilationUnit cu, boolean quiet) {
        String packageName = cu.getPackage().getName().toString();
        List<TypeDeclaration> types = cu.getTypes();
        for (TypeDeclaration type : types) {
        	String className = type.getName();
        	
            String fullClassName = packageName + "." + className;
            
        	List<BodyDeclaration> members = type.getMembers();
            for (BodyDeclaration member : members) {
                if (member instanceof MethodDeclaration) {
                    MethodDeclaration method = (MethodDeclaration) member;
                    String methodName = method.getName();
                    List<AnnotationExpr> annotations = method.getAnnotations();
                    boolean isTestMethod = false;
                    for (AnnotationExpr annotationExpr : annotations) {
						if("Ignore".equals(annotationExpr.getName().getName())){
								isTestMethod = false;
								break;
						} else if("Test".equals(annotationExpr.getName().getName())){
							isTestMethod = true;
							continue;
						}
					}
                    if(isTestMethod){
                    	testMethods.add(new TestMethod(methodIndex, packageName, className, methodName));
                        // result.add(fullClassName + " #" + methodName);
                        
                    	methodIndex++;
                    }
                }
            }
            // System.out.println();
        }
    }
	
    /**
     * Simple visitor implementation for visiting MethodDeclaration nodes. 
     */
    @SuppressWarnings({ "rawtypes", "unused" })
	private static class MethodVisitor extends VoidVisitorAdapter {

        @Override
        public void visit(MethodDeclaration n, Object arg) {
            // here you can access the attributes of the method.
            // this method will be called for all methods in this 
            // CompilationUnit, including inner class methods
            // System.out.println(n.getName());
        }
    }

	public List<TestMethod> getTestMethods() {
		return testMethods;
	}


	public void setTestMethods(List<TestMethod> testMethods) {
		this.testMethods = testMethods;
	}
    
    
}
