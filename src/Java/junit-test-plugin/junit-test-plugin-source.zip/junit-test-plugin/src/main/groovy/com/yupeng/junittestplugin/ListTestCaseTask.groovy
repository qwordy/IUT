package com.yupeng.junittestplugin
import org.gradle.api.Project
import org.gradle.api.DefaultTask
import org.gradle.api.tasks.TaskAction
import org.gradle.api.tasks.SourceSetContainer
import org.gradle.api.tasks.SourceSet
import java.util.Set
import java.io.File

/**
 *
 * @author YuPeng
 * list all junit test cases, with its classpath and all of its test methods
 * for all (sub)projects
 * 
 */


class ListTestCaseTask extends DefaultTask {
	@TaskAction
	def list() {
		Project project = getProject()
		//println "projectName: " + project.getName()
		list(project, project)
		project.getSubprojects().each { sub ->
			list(sub, project)
		}

	}
	
	// list all junit test cases, with its classpath and all of its test methods
	def list(Project p, Project root) {
		if(p.getPluginManager().hasPlugin("java")) {
			//println project.getName() + " has java plugin"
			def sources = p.getProperties().get("sourceSets")
			sources.each { sourceSet ->
				if(sourceSet.getName().equals("test")){ // for test java
					def srcs = sourceSet.getJava().getSrcDirs()
					srcs.each { src ->
						println "**************************"
						println "******  test cases in " + root.relativePath(src.getCanonicalPath()) + "\n"

                        new TestMethodParser().listTests(sourceSet.getJava().getFiles(), false, src.getCanonicalPath())

						println "******  classpath for test cases in " + root.relativePath(src.getCanonicalPath()) + "\n"
					    def files =  sourceSet.getRuntimeClasspath()
					    files.each { file ->
                            println "\t" + file.getCanonicalPath()
						}
                        println ""
					}
				}
			}
		} else {
			//println project.getName() + " doesn't have java plugin"
		}
	}
}
