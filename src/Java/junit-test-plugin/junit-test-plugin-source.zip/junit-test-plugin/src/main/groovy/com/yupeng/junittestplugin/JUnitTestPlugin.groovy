package com.yupeng.junittestplugin

import org.gradle.api.Project
import org.gradle.api.Plugin

class JUnitTestPlugin implements Plugin<Project> {
    void apply(Project target) {
        target.task('hello', type: GreetingTask)
        target.task('listSrcDirs', type: ListSourceDirTask)
        target.task('listJUnitTestCases', type: ListTestCaseTask)
    }
}
