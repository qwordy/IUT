package com.yupeng.junittestplugin;

/**
 * @author YuPeng
 *
 */
public class TestMethod {
	private int id;
	private String packageName;
	private String className;
	private String methodName;

	public TestMethod(int id, String packageName, String className,
			String methodName) {
		super();
		this.id = id;
		this.packageName = packageName;
		this.className = className;
		this.methodName = methodName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getMethodName() {
		return methodName;
	}

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	public String toTestString() {
		return packageName + "." + className + "." + methodName;
	}
}
